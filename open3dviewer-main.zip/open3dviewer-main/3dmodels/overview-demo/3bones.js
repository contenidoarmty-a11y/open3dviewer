globalThis.subset = ['l-Bones','l-Bones_left','l-Bones_right','l-Muscles_left','l-Muscles_right','++Scapula.r','++Humerus.r','++Clavicle.r'];
globalThis.menuoff = false;
