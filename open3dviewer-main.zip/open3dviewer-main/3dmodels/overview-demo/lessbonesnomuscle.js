globalThis.subset = ['l-Bones','l-Muscles_left','--Rib (8th).l','--Rib (7th).l','--Rib (7th).l','--Humerus.l'];
globalThis.menuoff = false;



